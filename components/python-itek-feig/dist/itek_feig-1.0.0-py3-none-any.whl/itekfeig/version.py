"""
Current module/library version
"""
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

version = "1.0.0"
