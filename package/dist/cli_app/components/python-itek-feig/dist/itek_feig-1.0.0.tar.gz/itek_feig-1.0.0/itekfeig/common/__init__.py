"""
Contains common code required by most readers
"""
